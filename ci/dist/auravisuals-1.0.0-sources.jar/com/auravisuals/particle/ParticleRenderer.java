package com.auravisuals.particle;

import com.auravisuals.config.ModConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Draws every active particle as a camera-facing glowing quad with additive
 * blending, which gives a cheap "shader-like" glow without needing a real
 * shader pack or a custom GLSL pipeline.
 */
public final class ParticleRenderer {

	private ParticleRenderer() {
	}

	public static void render(WorldRenderContext context) {
		ModConfig config = ModConfig.get();
		ParticleManager manager = ParticleManager.getInstance();

		if (manager.getAmbientParticles().isEmpty() && manager.getAuraParticles().isEmpty()) {
			return;
		}

		class_243 camPos = context.camera().method_19326();
		class_4587 matrices = context.matrixStack();
		if (matrices == null) {
			return;
		}

		// Camera-facing basis vectors, so every quad billboards towards the player.
		Vector3f right = new Vector3f(1, 0, 0).rotate(context.camera().method_23767());
		Vector3f up = new Vector3f(0, 1, 0).rotate(context.camera().method_23767());

		matrices.method_22903();
		matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);

		RenderSystem.enableBlend();
		RenderSystem.blendFunc(
				com.mojang.blaze3d.platform.GlStateManager.class_4535.SRC_ALPHA,
				com.mojang.blaze3d.platform.GlStateManager.class_4534.ONE); // additive glow
		RenderSystem.depthMask(false);
		RenderSystem.disableCull();
		RenderSystem.setShader(class_757::method_34540);

		class_289 tessellator = class_289.method_1348();
		class_287 buffer = tessellator.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
		Matrix4f matrix = matrices.method_23760().method_23761();

		if (config.ambientEnabled) {
			int argb = config.ambientColor;
			for (FloatingParticle p : manager.getAmbientParticles()) {
				float alpha = p.lifeAlpha() * 0.85f;
				addQuad(buffer, matrix, right, up, p, argb, alpha);
			}
		}

		if (config.auraEnabled) {
			int argb = config.auraColor;
			for (FloatingParticle p : manager.getAuraParticles()) {
				float alpha = manager.auraAlpha(p) * 0.9f;
				addQuad(buffer, matrix, right, up, p, argb, alpha);
			}
		}

		class_286.method_43433(buffer.method_60800());

		RenderSystem.depthMask(true);
		RenderSystem.enableCull();
		RenderSystem.defaultBlendFunc();
		RenderSystem.disableBlend();

		matrices.method_22909();
	}

	private static void addQuad(class_287 buffer, Matrix4f matrix, Vector3f right, Vector3f up,
			FloatingParticle p, int rgb, float alpha) {
		if (alpha <= 0f) return;

		float r = ((rgb >> 16) & 0xFF) / 255f;
		float g = ((rgb >> 8) & 0xFF) / 255f;
		float b = (rgb & 0xFF) / 255f;

		float hs = p.size; // half-size
		float x = (float) p.x;
		float y = (float) p.y;
		float z = (float) p.z;

		float x1 = x - right.x * hs - up.x * hs;
		float y1 = y - right.y * hs - up.y * hs;
		float z1 = z - right.z * hs - up.z * hs;

		float x2 = x + right.x * hs - up.x * hs;
		float y2 = y + right.y * hs - up.y * hs;
		float z2 = z + right.z * hs - up.z * hs;

		float x3 = x + right.x * hs + up.x * hs;
		float y3 = y + right.y * hs + up.y * hs;
		float z3 = z + right.z * hs + up.z * hs;

		float x4 = x - right.x * hs + up.x * hs;
		float y4 = y - right.y * hs + up.y * hs;
		float z4 = z - right.z * hs + up.z * hs;

		buffer.method_22918(matrix, x1, y1, z1).method_22915(r, g, b, alpha);
		buffer.method_22918(matrix, x2, y2, z2).method_22915(r, g, b, alpha);
		buffer.method_22918(matrix, x3, y3, z3).method_22915(r, g, b, alpha);
		buffer.method_22918(matrix, x4, y4, z4).method_22915(r, g, b, alpha);
	}
}
