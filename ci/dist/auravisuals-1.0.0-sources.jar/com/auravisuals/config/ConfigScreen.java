package com.auravisuals.config;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_4185;
import net.minecraft.class_437;

/**
 * Plain vanilla-widget config screen - no extra GUI library dependency needed.
 * Open with the keybinding registered in AuraVisualsClient (default: comma ",").
 */
public class ConfigScreen extends class_437 {

	private final class_437 parent;

	private class_4185 ambientToggle;
	private class_4185 auraToggle;
	private class_342 ambientColorField;
	private class_342 auraColorField;

	// Working copy, only written back to ModConfig on Save.
	private boolean ambientEnabled;
	private boolean auraEnabled;
	private int ambientColor;
	private int auraColor;
	private float density;
	private float speed;

	public ConfigScreen(class_437 parent) {
		super(class_2561.method_43471("auravisuals.config.title"));
		this.parent = parent;
	}

	@Override
	protected void method_25426() {
		ModConfig config = ModConfig.get();
		ambientEnabled = config.ambientEnabled;
		auraEnabled = config.auraEnabled;
		ambientColor = config.ambientColor;
		auraColor = config.auraColor;
		density = config.density;
		speed = config.speed;

		int centerX = this.field_22789 / 2;
		int top = this.field_22790 / 2 - 90;
		int rowHeight = 24;
		int fieldWidth = 200;

		// Ambient toggle
		ambientToggle = class_4185.method_46430(toggleLabel("auravisuals.config.ambient.toggle", ambientEnabled), btn -> {
			ambientEnabled = !ambientEnabled;
			btn.method_25355(toggleLabel("auravisuals.config.ambient.toggle", ambientEnabled));
		}).method_46434(centerX - fieldWidth / 2, top, fieldWidth, 20).method_46431();
		this.method_37063(ambientToggle);

		// Ambient color field
		ambientColorField = new class_342(this.field_22793, centerX - fieldWidth / 2, top + rowHeight, fieldWidth, 20,
				class_2561.method_43471("auravisuals.config.ambient.color"));
		ambientColorField.method_1880(6);
		ambientColorField.method_1852(toHex(ambientColor));
		this.method_37063(ambientColorField);

		// Aura toggle
		auraToggle = class_4185.method_46430(toggleLabel("auravisuals.config.aura.toggle", auraEnabled), btn -> {
			auraEnabled = !auraEnabled;
			btn.method_25355(toggleLabel("auravisuals.config.aura.toggle", auraEnabled));
		}).method_46434(centerX - fieldWidth / 2, top + rowHeight * 2 + 6, fieldWidth, 20).method_46431();
		this.method_37063(auraToggle);

		// Aura color field
		auraColorField = new class_342(this.field_22793, centerX - fieldWidth / 2, top + rowHeight * 3 + 6, fieldWidth, 20,
				class_2561.method_43471("auravisuals.config.aura.color"));
		auraColorField.method_1880(6);
		auraColorField.method_1852(toHex(auraColor));
		this.method_37063(auraColorField);

		// Density slider
		this.method_37063(new LabeledSlider(centerX - fieldWidth / 2, top + rowHeight * 4 + 14, fieldWidth, 20,
				"auravisuals.config.density", density, 0.1, 3.0, value -> density = (float) value));

		// Speed slider
		this.method_37063(new LabeledSlider(centerX - fieldWidth / 2, top + rowHeight * 5 + 14, fieldWidth, 20,
				"auravisuals.config.speed", speed, 0.1, 3.0, value -> speed = (float) value));

		// Save / Cancel
		this.method_37063(class_4185.method_46430(class_2561.method_43471("auravisuals.config.save"), btn -> save())
				.method_46434(centerX - fieldWidth / 2, top + rowHeight * 6 + 24, fieldWidth / 2 - 4, 20).method_46431());

		this.method_37063(class_4185.method_46430(class_2561.method_43471("auravisuals.config.cancel"), btn -> method_25419())
				.method_46434(centerX + 4, top + rowHeight * 6 + 24, fieldWidth / 2 - 4, 20).method_46431());
	}

	private class_2561 toggleLabel(String key, boolean enabled) {
		String state = enabled ? "auravisuals.config.on" : "auravisuals.config.off";
		return class_2561.method_43471(key).method_27693(": ").method_10852(class_2561.method_43471(state));
	}

	private static String toHex(int rgb) {
		return String.format("%06X", rgb & 0xFFFFFF);
	}

	private static int parseHexOrDefault(String text, int fallback) {
		try {
			String cleaned = text.replace("#", "").trim();
			if (cleaned.isEmpty()) return fallback;
			return Integer.parseInt(cleaned, 16) & 0xFFFFFF;
		} catch (NumberFormatException e) {
			return fallback;
		}
	}

	private void save() {
		ModConfig config = ModConfig.get();
		config.ambientEnabled = ambientEnabled;
		config.auraEnabled = auraEnabled;
		config.ambientColor = parseHexOrDefault(ambientColorField.method_1882(), config.ambientColor);
		config.auraColor = parseHexOrDefault(auraColorField.method_1882(), config.auraColor);
		config.density = density;
		config.speed = speed;
        config.save();
		method_25419();
	}

	@Override
	public void method_25419() {
		if (this.field_22787 != null) {
			this.field_22787.method_1507(parent);
		}
	}

	@Override
	public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
		this.method_25420(context, mouseX, mouseY, delta);
		super.method_25394(context, mouseX, mouseY, delta);
		context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, this.field_22790 / 2 - 110, 0xFFFFFF);

		// Live color swatches next to the hex fields, so you see the color before saving.
		int liveAmbient = parseHexOrDefault(ambientColorField.method_1882(), ambientColor);
		int liveAura = parseHexOrDefault(auraColorField.method_1882(), auraColor);
		context.method_25294(ambientColorField.method_46426() + ambientColorField.method_25368() + 6, ambientColorField.method_46427(),
				ambientColorField.method_46426() + ambientColorField.method_25368() + 22, ambientColorField.method_46427() + 20,
				0xFF000000 | liveAmbient);
		context.method_25294(auraColorField.method_46426() + auraColorField.method_25368() + 6, auraColorField.method_46427(),
				auraColorField.method_46426() + auraColorField.method_25368() + 22, auraColorField.method_46427() + 20,
				0xFF000000 | liveAura);
	}

	@Override
	public boolean method_25421() {
		return false;
	}

	/** Small helper SliderWidget bound to a double value via a setter callback. */
	private static class LabeledSlider extends class_357 {
		private final String labelKey;
		private final double min;
		private final double max;
		private final java.util.function.DoubleConsumer onChange;

		LabeledSlider(int x, int y, int width, int height, String labelKey, double current, double min, double max,
				java.util.function.DoubleConsumer onChange) {
			super(x, y, width, height, class_2561.method_43473(), (current - min) / (max - min));
			this.labelKey = labelKey;
			this.min = min;
			this.max = max;
			this.onChange = onChange;
			method_25346();
		}

		private double currentValue() {
			return min + (max - min) * this.field_22753;
		}

		@Override
		protected void method_25346() {
			this.method_25355(class_2561.method_43471(labelKey).method_27693(": " + String.format("%.2f", currentValue())));
		}

		@Override
		protected void method_25344() {
			onChange.accept(currentValue());
		}
	}
}
