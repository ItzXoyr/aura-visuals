package com.auravisuals;

import com.auravisuals.config.ConfigScreen;
import com.auravisuals.config.ModConfig;
import com.auravisuals.particle.ParticleManager;
import com.auravisuals.particle.ParticleRenderer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class AuraVisualsClient implements ClientModInitializer {

	private static class_304 openConfigKey;

	@Override
	public void onInitializeClient() {
		// Load (or create) the config as soon as possible.
		ModConfig.get();

		openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.auravisuals.open_config",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_COMMA,
				"key.category.auravisuals"
		));

		ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
		WorldRenderEvents.AFTER_TRANSLUCENT.register(ParticleRenderer::render);
	}

	private void onClientTick(class_310 client) {
		ParticleManager.getInstance().tick(client);

		while (openConfigKey.method_1436()) {
			if (client.field_1755 == null) {
				client.method_1507(new ConfigScreen(null));
			}
		}
	}
}
