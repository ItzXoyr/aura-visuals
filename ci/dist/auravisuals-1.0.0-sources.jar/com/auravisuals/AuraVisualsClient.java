package com.auravisuals;

import com.auravisuals.config.ConfigScreen;
import com.auravisuals.config.ModConfig;
import com.auravisuals.particle.ParticleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class AuraVisualsClient implements ClientModInitializer {

	private static class_304 openConfigKey;

	// Minecraft 1.21.9+ requires a KeyBinding.Category object instead of a bare translation string.
	private static final class_304.class_11900 CATEGORY =
			class_304.class_11900.method_74698(class_2960.method_60655("auravisuals", "main"));

	@Override
	public void onInitializeClient() {
		// Load (or create) the config as soon as possible.
		ModConfig.get();

		openConfigKey = KeyBindingHelper.registerKeyBinding(new class_304(
				"key.auravisuals.open_config",
				class_3675.class_307.field_1668,
				GLFW.GLFW_KEY_COMMA,
				CATEGORY
		));

		ClientTickEvents.END_CLIENT_TICK.register(this::onClientTick);
		// No custom world-render hook needed: particles are spawned through the vanilla
		// particle system (see ParticleManager), which Mojang keeps stable across the
		// rendering-pipeline rewrites that broke our old hand-rolled renderer.
	}

	private void onClientTick(class_310 client) {
		ParticleManager.getInstance().tick(client);

		while (openConfigKey.method_1436()) {
			if (client.field_1755 == null) {
				client.method_1507(new ConfigScreen(null));
			}
		}
	}
}
